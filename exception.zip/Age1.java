package com.exception;
import java.util.*;
public class Age1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age;
		System.out.println("enter an age");
		Scanner s=new Scanner(System.in);
		age=s.nextInt();
		if(age<18)
		{
				throw new AgeValidation("Invalid User");
		}
	
	}

}
