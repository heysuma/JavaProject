package com.exception;

public class AgeValidation extends RuntimeException{
	String message;

	public AgeValidation(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	
	
}
