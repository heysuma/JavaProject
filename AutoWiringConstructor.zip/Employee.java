
public class Employee 
{
	private Address addr;//type of variable
	private int salary;

	public Employee(){}


	public Employee(Address addr)
	{
		this.addr = addr;
	}

	public Address getAddr()
	{
		return addr;
	}
	public void setAddr(Address addr)
	{
		this.addr = addr;
	}


	public int getSalary() {
		return salary;
	}


	public void setSalary(int salary) {
		this.salary = salary;
	}


	@Override
	public String toString() {
		return "Employee [addr=" + addr + ", salary=" + salary + "]";
	}


	
}
