package com.test;
import com.bean.Book;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.dao.BookDao;


@WebServlet("/BookServlet")
public class BookServlet extends HttpServlet {
	
	BookDao bd=null;
	private static final long serialVersionUID = 1L;
       
  
    public BookServlet() {
        super();
        bd=new BookDao();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int  id=Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("bname");
		int  p=Integer.parseInt(request.getParameter("bprice"));
		
		Book book=new Book();
		book.setId(id);
		book.setName(name);
		book.setPrice(p);
		
			try {
				bd.saveBook(book);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
	}

}
