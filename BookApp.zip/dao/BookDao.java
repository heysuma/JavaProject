package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bean.Book;

public class BookDao {
	
	private Connection con;
	

	public void saveBook(Book book) throws  ClassNotFoundException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/suma";
		String username="root";
		String password="Cuty@1998#";
		
				
				try {
					Connection con=DriverManager.getConnection(url,username,password);
				
				String qr="insert into books values(?,?,?)";
				
				PreparedStatement ps=con.prepareStatement(qr);
				ps.setInt(1, book.getId());
				ps.setString(2, book.getName());
				ps.setInt(3, book.getPrice());
				ps.executeUpdate();
				//con.commit();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				
	}
				public void removeBook(int id) {
			        try{
			        	String sql = "DELETE FROM users WHERE userid=?";
			            PreparedStatement ps=con .prepareStatement(sql);
			            ps.setInt(1, id);
			            ps.executeUpdate();

			        } catch (SQLException e) {
			            e.printStackTrace();
			        }
			      }
	
}
