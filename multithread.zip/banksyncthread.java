package multithread;
class customer{
	int amount=0;
	int flag=0;
	public synchronized void withdrawl(int amount)
	{
		System.out.println(Thread.currentThread().getName()+ " is going to withdrawl");
		if(flag==0)
		{
			try{
				System.out.println("wait...there is no balnce till the amount get deposited in account");
				wait();
			}catch(Exception e)
			{
				System.out.println("Insufficient amount");
			}
			
		}
		this.amount-=amount;
		System.out.println(" withdrawl amount is"+amount);
	}
	
	
	public synchronized void deposit(int amount)
	{
		System.out.println(Thread.currentThread().getName()+ " is going to deposit");
		this.amount+=amount;
		System.out.println("the deposit amount is"+amount);
		notifyAll();
		flag=1;
	}
}


public class banksyncthread {
	public static void main(String args[])
	{
		customer c=new customer();
		Thread t1=new Thread()
		{
			public void run()
			{
				c.withdrawl(5000);
				System.out.println("after withdrawl the amount is"+c.amount);
			}	
		};
		Thread t2=new Thread()
		{
			public void run()
			{
				c.deposit(7000);
				c.deposit(2000);
				System.out.println("the deposit amount is"+c.amount);
				
			}
		};
		
		
		t1.setName("suma");
		t2.setName("sai");
		t1.start();
		t2.start();
	}

}
