package multithread;

public class TestThread1 implements Runnable 
{
		public void run()
		{
			System.out.println("in run method");
		}
		public static void main(String[] args)
		{
			TestThread t=new TestThread();
			Thread tt=new Thread(t);         //Thread tt=new Thread(new TestThread());
			
			tt.start();
		}
}
