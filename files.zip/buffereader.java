package examples;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class buffereader {
	public static void main(String args[]) throws IOException
	{
		try
		{
			FileReader fr=new FileReader("D:example.txt");
			BufferedReader buf=new BufferedReader(fr);
			String line;
			while((line =buf.readLine())!=null)
					{
						System.out.println(line);
					}
			fr.close();
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
