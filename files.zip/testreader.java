package examples;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class testreader {
	public static void main(String args[])throws Exception
	{
		try{
			FileReader fr=new FileReader("D:example.txt");
			int c;
				while((c=fr.read())!=-1)
				{
					System.out.println((char)c);
				}
				fr.close();
			} 
		catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
}
