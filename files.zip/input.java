package examples;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStreamReader;

public class input {
	public static void main(String args[])throws Exception
	{
	try
	{
		FileInputStream f=new FileInputStream("D:example.txt");
		InputStreamReader buff=new InputStreamReader(f);
		int line;
		while((line =buff.read())!=-1)
				{
					System.out.println((char)line);
				}
		f.close();
	}catch (FileNotFoundException e) {
		e.printStackTrace();
	}
}
}
