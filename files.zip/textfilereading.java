package examples;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

public class textfilereading {
public static void main(String args[])throws Exception
{
	try
	{
		FileInputStream f=new FileInputStream("D:example.txt");
		InputStreamReader buff=new InputStreamReader(f,"UTF-8");
		int line;
		while((line =buff.read())!=-1)
				{
					System.out.println((char)line);
				}
		f.close();
	}catch (FileNotFoundException e) {
		e.printStackTrace();
	}
	}
}

