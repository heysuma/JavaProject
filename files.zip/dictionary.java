package examples;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeSet;

public class dictionary {
	private Map<String,TreeSet<String>> dictionary;
	public dictionary (){
		dictionary=new LinkedHashMap();
	};
	public void add(String word)
	{
		String key=" "+word.charAt(0);
		TreeSet<String> words=dictionary.get(key);
		if(words==null)
		{
			words=new TreeSet<>();
			words.add(word);
			dictionary.put(key, words);
		}
	}
		 public TreeSet<String> get(String key)
		{
			return this.dictionary.get(key);
			
		}
	}
