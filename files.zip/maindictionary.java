package examples;

public class maindictionary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dictionary dictionary=new dictionary();
		dictionary.add("aeroplane");
		dictionary.add("car");
		dictionary.add("air");
		dictionary.add("bus");
		dictionary.add("vehicle");
		dictionary.add("Van");
		dictionary.add("Zebra");
		dictionary.add("torture");
		System.out.println(dictionary.get("a"));
	}

}
