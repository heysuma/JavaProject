package examples;

import java.io.Serializable;
import java.util.Date;

public class user implements Serializable {
		private static final long serialVersionUID=1234L;
		private String username;
		private String email;
		private transient String password;
		private Date birthday;
		private int age;
		public user(String username, String email, String password, Date birthday, int age) {
			super();
			this.username = username;
			this.email = email;
			this.password = password;
			this.birthday = birthday;
			this.age = age;
		}
		public void printInfo()
		{
			System.out.println("username:"+username);
			System.out.println("mailid:" +email);
			System.out.println("password:"+password);
			System.out.println("birthday:"+birthday);
			System.out.println("age:"+age);
			
		}

}
