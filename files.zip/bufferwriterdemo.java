package examples;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class bufferwriterdemo{
	public static void main(String[] args) {
		try{
			FileWriter writer=new FileWriter("D:example.txt",true);
			BufferedWriter b=new BufferedWriter(writer);
			writer.write("hello");
			writer.write("\r\n");
			writer.write("good bye");
			writer.close();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}
