package com.setter;

public class Customer {
	person p;

	public person getP() {
		return p;
	}

	public void setP(person p) {
		this.p = p;
	}

	@Override
	public String toString() {
		return "Customer [p=" + p + "]";
	}
}
