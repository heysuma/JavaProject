package com.setter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSetter {
public static void main(String args[])
{
	ApplicationContext con=new ClassPathXmlApplicationContext("applicationContext.xml");
	Customer obj=(Customer)con.getBean("cust2");
	System.out.println(obj);
}
}
