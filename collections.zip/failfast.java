package listprograms;

import java.util.ArrayList;
import java.util.Iterator;



public class failfast 
{
	public static void main(String args[])
	{
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(123);
		list.add(543);
		list.add(432);
		Iterator<Integer> it= list.iterator();
		while(it.hasNext())
		{
			Integer integer=(Integer) it.next();
			list.add(7654);
		}
	}
}