package listprograms;

public class registration {
private String name;
private String mailid;
private String mobileno;
private String total;
public registration(String name, String mailid, String mobileno, String total) {
	super();
	this.name = name;
	this.mailid = mailid;
	this.mobileno = mobileno;
	this.total = total;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMailid() {
	return mailid;
}
public void setMailid(String mailid) {
	this.mailid = mailid;
}
public String getMobileno() {
	return mobileno;
}
public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}
public String getTotal() {
	return total;
}
public void setTotal(String total) {
	this.total = total;
}
public String toString()
{
	return "Registration [name=" +name+ ",mailid=" +mailid+",mobileno=" +mobileno+",total="+ total+"]";
	
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((mailid == null) ? 0 : mailid.hashCode());
	result = prime * result + ((mobileno == null) ? 0 : mobileno.hashCode());
	result = prime * result + ((name == null) ? 0 : name.hashCode());
	result = prime * result + ((total == null) ? 0 : total.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	registration other = (registration) obj;
	if (mailid == null) {
		if (other.mailid != null)
			return false;
	} else if (!mailid.equals(other.mailid))
		return false;
	if (mobileno == null) {
		if (other.mobileno != null)
			return false;
	} else if (!mobileno.equals(other.mobileno))
		return false;
	if (name == null) {
		if (other.name != null)
			return false;
	} else if (!name.equals(other.name))
		return false;
	if (total == null) {
		if (other.total != null)
			return false;
	} else if (!total.equals(other.total))
		return false;
	return true;
}

}

