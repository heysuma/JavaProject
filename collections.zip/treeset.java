package listprograms;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

public class treeset 
{
	public static void main(String args[])
	{
		TreeMap<Integer,String> tset=new TreeMap<Integer,String>();
		tset.put(1, "14");
		tset.put(7, "4");
		tset.put(3, "72");
		tset.put(4, "null");
		System.out.println(tset);
		for(Map.Entry me: tset.entrySet())
		{
			System.out.println("key:"+me.getKey()+"&value:"+me.getValue());
		}
	}
}

	

