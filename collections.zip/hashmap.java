package listprograms;

import java.util.HashMap;
import java.util.Map;

public class hashmap 
{
	public static void main(String args[])
	{
		HashMap<Integer,String> hmap=new HashMap<>();
		hmap.put(1, "14");
		hmap.put(7, "4");
		hmap.put(3, "7 2");
		hmap.put(4, "null");
		System.out.println(hmap);
		for(Map.Entry me: hmap.entrySet())
		{
			System.out.println("key:"+me.getKey()+"&value:"+me.getValue());
		}
	}
}

	
