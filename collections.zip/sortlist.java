package listprograms;

import java.util.ArrayList;
import java.util.Collections;

public class sortlist {
public static void main(String args[])
{
	ArrayList<String> s1=new ArrayList<String>();
	s1.add("Rahul");
	s1.add("Ravi");
	s1.add("Suma");
	s1.add("Anu");
	s1.add("Leela");
	Collections.sort(s1);
	
	System.out.println(s1);
}
}
