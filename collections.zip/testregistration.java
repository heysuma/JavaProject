package listprograms;

import java.util.Scanner;

public class testregistration {
public static void main(String args[])
{
	String name,mobileno,mailid;
	String total;
	System.out.println("enter registration 1 details:");
	Scanner s=new Scanner(System.in);
	name=s.nextLine();
	mobileno=s.nextLine();
	mailid=s.nextLine();
	total=s.nextLine();
	
	System.out.println("enter registration 2 details:");
	Scanner s1=new Scanner(System.in);
	name=s1.nextLine();
	mobileno=s.nextLine();
	mailid=s.nextLine();
	total=s.nextLine();
	
	if(s.equals(s1))
	{
		System.out.println("Two objects are same");
	}
	else
		System.out.println("Two objects are not same");
}
}
