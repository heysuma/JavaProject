package listprograms;

public class garbagecollector {
public static void main(String args[])throws InterruptedException
{
	garbagecollector  t1=new garbagecollector ();
	garbagecollector  t2=new garbagecollector ();
	t1=null;
	System.gc();//requesting Jvm for running garbage Collector
	t2=t1;	//nullifying the reference variable
	Runtime.getRuntime().gc();
}
protected void finalize() throws Throwable
{
	System.out.println("Garbage collector called");
	System.out.println("object garbage collected:" +this);
}
}
