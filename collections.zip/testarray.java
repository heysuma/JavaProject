package listprograms;

import java.awt.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;


public class testarray {
	public static void main(String args[])
	{
		ArrayList li=new ArrayList();
		li.add(10);
		li.add("Rahul");
		li.add(12.4);
		System.out.println(li);
		
		ArrayList l1=new ArrayList();
		l1.add("meena");
		l1.add("18");
		l1.add("Rahul");
		l1.add(null);
		l1.add(null);
		System.out.println(l1);
		
		
		l1.add(1,13);		//add an element in an particular position
		System.out.println(l1);
		
		if(l1.contains(10))			//we used to know wheter the value is exists or not
		{
			System.out.println("value exists");
		}
		else
			System.out.println("value does not exists");
		
		
		li.addAll(l1);		//we used to combine the two lists
		System.out.println(li);
		
		
		
		if(l1.isEmpty())	//it checks whether the list is empty or not
		{
				System.out.println("empty list collection");
		}
		else
			System.out.println("List is not empty");
		
		
		
		System.out.println("Convert ArrayList to Array");
		Object ob[]=li.toArray();	//in this we convert the array list to array
		for(Object o:ob)
		{
			System.out.println(o);
		}
		
		
		Iterator it= li.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		Object ob1=li.get(1);	//get the value at a position 
		System.out.println(ob1);
		
		int ind=li.indexOf(13);		//we will get the index value where the value is located
		System.out.println("index of "+ind);
		
		
		li.remove("meena");			//we remove the element in an array list
		System.out.println(li);
		
		li.removeAll(l1);			//we remove the entire list
		System.out.println(li);
		
		
	}
}
