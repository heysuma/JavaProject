package listprograms;

import java.util.ArrayList;
import java.util.Collections;

class comparable{

	public static  void main(String[] args) {
		ArrayList<student> al=new ArrayList<student>();
		al.add(new student(123,23,"rahul"));
		al.add(new student(204,25,"suma"));
		al.add(new student(67,32,"ajeet"));
		Collections.sort(al,student.com);
		for(student str: al)
			System.out.println(str);
	}
}
