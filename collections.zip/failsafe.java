package listprograms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

public class failsafe 
{
	public static void main(String args[])
	{
		ConcurrentHashMap<Integer,String> map=new ConcurrentHashMap<Integer,String>();
		map.put(1,"one");
		map.put(2,"two");
		map.put(3,"three");
		Iterator<Integer> it= map.keySet().iterator();
		while(it.hasNext())
		{
			Integer key=(Integer) it.next();
			System.out.println(key+" :"+map.get(key));
			map.put(4, "four");
		}
	}
}
