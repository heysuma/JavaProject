package listprograms;
import java.util.*;

public class student  {

	static int age;
	int rollno;
	String stuname;
	public student(int age, int rollno, String stuname) {
		super();
		this.age = age;
		this.rollno = rollno;
		this.stuname = stuname;
	}

	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getStuname() {
		return stuname;
	}
	public void setStuname(String stuname) {
		this.stuname = stuname;
	}
	public String toString()
	{
		return "student [age=" +age + ",rollno=" +rollno+",stuname=" + stuname + "]";
	}
	public static Comparator<student> com=new Comparator<student>(){
		public int compare(student s1,student s2)
		{
			int age1=s1.getAge();
			int age2=s2.getAge();
			return age1-age2;
		}
	};
	public  int compareTo(Object comparestu)
	{
		int compareage=((student)comparestu).getAge();
		return this.age-compareage;
	}
	}
	

