package com.streamAPI;

import java.util.ArrayList;
import java.util.List;

public class StreamExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> names=new ArrayList<String>();
		names.add("ajay");
		names.add("suma");
		names.add("Lakshmi");
		names.add("sai");
		names.add("arjun");
		long count=names.stream().filter(str->str.length()<6).count();
		System.out.println("there are  " +count+ " strings with less than 6");
	}

}
