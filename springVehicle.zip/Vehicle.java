package com.bean;

import org.springframework.beans.factory.annotation.Required;

public class Vehicle {
 private String vname;
 private int nowheel;

public int getNowheel() {
	return nowheel;
}

public void setNowheel(int nowheel) {
	this.nowheel = nowheel;
}

public String getVname() {
	return vname;
}

public void setVname(String vname) {
	this.vname = vname;
}

@Override
public String toString() {
	return "Vehicle [vname=" + vname + ", nowheel=" + nowheel + "]";
}





}
