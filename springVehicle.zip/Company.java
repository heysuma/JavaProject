package com.bean;

import org.springframework.beans.factory.annotation.Autowired;

public class Company {
	@Autowired
	Vehicle vh;

	public Company(Vehicle vh) {
		super();
		this.vh = vh;
	}

	

	public Vehicle getVh() {
		// TODO Auto-generated method stub
		return vh;
	}
	
}
