package com.innerclass;
/*interface Age							//using interfaces
{
	int x=21;
	public abstract void getAge();
}*/
class Age								//using class that is nested class
{
	int x=21;
	public void getAge(){}
}
class AnonymousDemo {
	public static void main(String args[])
	{
		Age obj1=new Age(){
			public void getAge()
			{
				System.out.println("Age is "+x);
			}
		};
		obj1.getAge();
}
}