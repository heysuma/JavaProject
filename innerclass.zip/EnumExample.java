package com.innerclass;
enum Directions{
	EAST,WEST,NORTH,SOUTH
}
public class EnumExample {
private static Object dir;

/*public static void main(String args[])
{
	Directions dir=Directions.NORTH;
	if(dir==Directions.EAST)
	{
		System.out.println("Direction: EAST");
	}
	else if(dir==Directions.WEST)
	{
		System.out.println("Direction: WEST");
	}
	else if(dir==Directions.NORTH)
	{
		System.out.println("Direction: NORTH");
	}
	else
	{
		System.out.println("Direction: SOUTH");
	}
}*/
public static void main(String args[]){
Directions d;
d=Directions.NORTH;
	switch(d){
	case EAST:
		System.out.println("Direction: EAST");
		break;
	case WEST:
		System.out.println("Direction: WEST");
		break;
		
	case NORTH:
		System.out.println("Direction: NORTH");
		break;
		
	case SOUTH:
			System.out.println("Direction: SOUTH");
			break;
	}

/*for(Directions d:Directions.values())
{
	System.out.println("Values:"+d);
}*/
}

}

