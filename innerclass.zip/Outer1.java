package com.innerclass;

public class Outer1 {
static int x=100;
static class Inner{
	int y=200;
	void show()
	{
		System.out.println(x+" "+y);
	}
}
	/*public void display() {
		Inner n=new Inner();
		n.show();
	}*/

public static void main(String args[])
{
	//Outer1 obj=new Outer1();
	//obj.display();
	Outer1.Inner obj=new Outer1. Inner();
	obj.show();
	}

}
