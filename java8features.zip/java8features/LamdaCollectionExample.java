package com.java8features;

import java.util.ArrayList;
import java.util.List;

public class LamdaCollectionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list=new ArrayList<String>();
		list.add("maddula");
		list.add("sai");
		list.add("lakshmi");
		list.add("suma");
		list.forEach((s)->System.out.println(s));
	}

}
