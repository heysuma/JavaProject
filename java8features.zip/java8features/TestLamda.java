package com.java8features;

/*interface TestPi{
public double getPi();
}

public class TestLamda {
public static void main(String[] args)
{
	TestPi p=()->3.142;
	System.out.println("Pi value is:"+p.getPi());
}
}*/
/*interface Sum{
public int getSum(int x,int y);
}

public class TestLamda {
public static void main(String[] args)
{
	Sum p=(x,y)->x+y;
	System.out.println("Sum is:"+p.getSum(10,20));
}
}*/

interface Factorial{
	public int getfact(int n);
}
public class TestLamda{
	public static void main(String[] args)
{
		Factorial p=n->{
			int f=1;
			for(int i=1;i<=n;i++)
			f=i*f;
			return f;
			
		};
		System.out.println("factorial is:"+p.getfact(5));
}
}