package com.DateAPI;

import java.time.LocalDate;
import java.time.LocalTime;

public class DateExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate localDate=LocalDate.now();
		System.out.println(localDate.toString());
		System.out.println(localDate.getDayOfWeek().toString());
		System.out.println(localDate.getDayOfMonth());
		System.out.println(localDate.getDayOfYear());
		System.out.println(localDate.isLeapYear());
		
		LocalTime localTime=LocalTime.now();
		System.out.println(localTime.toString());
		
	}
	

}
